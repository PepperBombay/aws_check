from django.contrib import admin
from django.urls import path, include  # include를 추가하세요

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('security_monitor.urls')),  # security_monitor 앱의 URL 패턴을 포함
    # 다른 URL 패턴들을 여기에 추가
]