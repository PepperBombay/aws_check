from django.shortcuts import render

# Create your views here.

from .models import SecurityGroupLog

def view_security_group_logs(request):
    logs = SecurityGroupLog.objects.all()
    return render(request, 'security_monitor/security_group_logs.html', {'logs': logs})