from django.urls import path
from . import views

urlpatterns = [
    path('security_group_logs/', views.view_security_group_logs, name='security_group_logs'),
    # 다른 URL 패턴들은 이후 아래에 덧대기 
]