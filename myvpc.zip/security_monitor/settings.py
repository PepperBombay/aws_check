import os

# 기본 설정
DEBUG = True
SECRET_KEY = 'your-secret-key'
ALLOWED_HOSTS = []

# Timezone 설정
TIME_ZONE = 'Asia/Seoul'
USE_TZ = True

# 현재 파일(settings.py)의 디렉토리를 기반으로 BASE_DIR를 설정합니다.
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 이후 DATABASES 설정 등에서 BASE_DIR를 사용할 수 있습니다.

# 정적 파일 및 미디어 파일 설정
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')


# db.sqlite3 파일의 경로 설정
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}

# 언어 및 로케일 설정
LANGUAGE_CODE = 'ko-KR'
USE_I18N = True
USE_L10N = True

# 앱 설정
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'security_monitor',  # 여기에 사용자 정의 앱을 추가합니다.
]


# 미들웨어 설정
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# 루트 URL 패턴 설정
ROOT_URLCONF = 'security_monitor.urls'

# Templates 디렉토리 설정
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# 인증 설정
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
]

# Static 파일 및 미디어 파일 서빙을 위한 URL 설정
STATIC_URL = '/static/'
MEDIA_URL = '/media/'

# Static 파일 및 미디어 파일을 개발 서버에서 서빙하기 위한 설정 (개발 환경에서만 사용)
if DEBUG:
    STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')]
    MEDIA_ROOT = os.path.join(BASE_DIR, 'media')