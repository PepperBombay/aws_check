from django.db import models

# Create your models here.
class SecurityGroupLog(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    resource_id = models.CharField(max_length=255)
    action = models.CharField(max_length=255)
    log_status = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.timestamp} - {self.resource_id}"