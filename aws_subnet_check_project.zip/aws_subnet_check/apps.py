from django.apps import AppConfig


class AwsSubnetCheckConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aws_subnet_check'
